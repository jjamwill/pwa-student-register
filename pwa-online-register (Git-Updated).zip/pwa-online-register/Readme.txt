This is a Progrssive Web App created using:
>>HTML5
>>Materialize (front-end framework)
>>JavaScript (Service Worker - sw.js & app.js, Database - db.js, UI - ui.js)
>>JSON (manifest file)
>>Firebase (Backend - Cloud Firestore)

Note: Run on a Local server to test the application. (I am using the Live Server from VS Code).

See UI images folder for screenshots 

