const students = document.querySelector('.students')
document.addEventListener('DOMContentLoaded', function() {
  // nav menu
  const menus = document.querySelectorAll('.side-menu');
  M.Sidenav.init(menus, {edge: 'left'});
  // add student form
  const forms = document.querySelectorAll('.side-form');
  M.Sidenav.init(forms, {edge: 'right'});
});

// render recipe data
const renderStudent = (data, id) => {

  const html = `
    <div class="card-panel student white row" data-id="${id}">
      <img src="/img/student.png" alt="student thumb">
      <div class="student-details">
        <div class="student-name">${data.name}</div>
        <div class="student-id">${data.id}</div>
      </div>
      <div class="student-delete">
        <i class="material-icons" data-id="${id}">delete</i>
      </div>
    </div>
  `;

  students.innerHTML += html;

};

// remove from DOM (Student List)
const removeStudent = (id) => {
  const student = document.querySelector(`.student[data-id=${id}]`);
  student.remove();
};