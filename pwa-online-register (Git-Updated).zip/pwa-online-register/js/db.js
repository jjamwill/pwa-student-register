// enable offline data
db.enablePersistence()
  .catch(function(err) {
    if (err.code == 'failed-precondition') {
      // probably multible tabs open at once
      console.log('persistance failed');
    } else if (err.code == 'unimplemented') {
      // lack of browser support for the feature
      console.log('persistance not available');
    }
  });

// real-time listener
db.collection('students').onSnapshot(snapshot => {
  snapshot.docChanges().forEach(change => {
    if(change.type === 'added'){
      renderStudent(change.doc.data(), change.doc.id);
    }
    if(change.type === 'removed'){
      // remove the document data from the web page
      removeStudent(change.doc.id);
    }
  });
});

// add student
const form = document.querySelector('form');
form.addEventListener('submit', evt => {
  evt.preventDefault();
  
  const student = {
    name: form.name.value,
    id: form.id.value
  };

  db.collection('students').add(student)
    .catch(err => console.log(err));

  form.name.value = '';
  form.id.value = '';
});

// remove student
const studentContainer = document.querySelector('.students');
studentContainer.addEventListener('click', evt => {

  if(evt.target.textContent === 'delete'){
    const id = evt.target.getAttribute('data-id');
    db.collection('students').doc(id).delete();
  }
});